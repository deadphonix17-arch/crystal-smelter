# Crystalcraft End Stone Smelter (standalone add-on)

Fabric 1.21.8 add-on for Crystalcraft Unlimited. No Better End / BCLib / WorldWeaver needed.

## Build
1. Install JDK 21 and Gradle 8.14+ (or copy `gradlew`, `gradlew.bat` and the `gradle/` folder from any Fabric/MCreator workspace into this folder).
2. In this folder run:  `gradle build`   (or `./gradlew build`)
3. Take `build/libs/crystalcraft_smelter-1.0.0.jar` (NOT the -sources jar).

## Install
mods folder: ORIGINAL Crystalcraft Unlimited jar + crystalcraft_smelter-1.0.0.jar + Fabric API.
(Better End, BCLib, WorldWeaver can be removed. Do not use the earlier modified Crystalcraft jar.)

## What it does
* Block: End Stone Smelter (crafted: blast furnace in the middle, 8 smooth stone around it).
* 2 input slots (either order), 1 fuel slot, 1 output. Fuel = anything a furnace can burn, incl. coal blocks.
* 204 recipes in `data/crystalcraft_smelter/smelter_recipes/` converted from Crystalcraft's smithing recipes
  (fusions, steel, withered steel, matrix/meteorite/neon upgrades). The smithing recipes are disabled by
  load-condition overrides in `data/crystalcraft_unlimited_java/recipe/`.
* Add your own recipes as JSON files in `smelter_recipes/` (ingredients may be item ids or `#tags`).
* Ore generation is untouched.

## Credits
Smelter textures/GUI from Better End (MIT, some assets CC BY-NC-SA 4.0) - keep credit if you share it.
