package com.crystalsmelter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.MapColor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CrystalSmelterMod implements ModInitializer {
    public static final String MOD_ID = "crystalcraft_smelter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final ResourceLocation SMELTER_ID = ResourceLocation.fromNamespaceAndPath(MOD_ID, "end_stone_smelter");

    public static Block SMELTER_BLOCK;
    public static Item SMELTER_ITEM;
    public static BlockEntityType<SmelterBlockEntity> SMELTER_BLOCK_ENTITY;
    public static MenuType<SmelterMenu> SMELTER_MENU;

    @Override
    public void onInitialize() {
        SMELTER_BLOCK = Registry.register(
                BuiltInRegistries.BLOCK, SMELTER_ID,
                new SmelterBlock(BlockBehaviour.Properties.of()
                        .setId(ResourceKey.create(Registries.BLOCK, SMELTER_ID))
                        .mapColor(MapColor.SAND)
                        .strength(3.5F)
                        .requiresCorrectToolForDrops()
                        .sound(SoundType.STONE)
                        .lightLevel(state -> state.getValue(BlockStateProperties.LIT) ? 13 : 0)));

        SMELTER_ITEM = Registry.register(
                BuiltInRegistries.ITEM, SMELTER_ID,
                new BlockItem(SMELTER_BLOCK, new Item.Properties()
                        .setId(ResourceKey.create(Registries.ITEM, SMELTER_ID))
                        .useBlockDescriptionPrefix()));

        SMELTER_BLOCK_ENTITY = Registry.register(
                BuiltInRegistries.BLOCK_ENTITY_TYPE, SMELTER_ID,
                FabricBlockEntityTypeBuilder.create(SmelterBlockEntity::new, SMELTER_BLOCK).build());

        SMELTER_MENU = Registry.register(
                BuiltInRegistries.MENU, SMELTER_ID,
                new MenuType<>(SmelterMenu::new, FeatureFlags.VANILLA_SET));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS)
                .register(entries -> entries.accept(SMELTER_ITEM));

        ResourceManagerHelper.get(PackType.SERVER_DATA).registerReloadListener(new SmelterRecipes());
    }
}
