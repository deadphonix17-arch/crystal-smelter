package com.crystalsmelter;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SmelterMenu extends AbstractContainerMenu {
    private final Container container;
    private final ContainerData data;
    private final Level level;

    /** Client-side constructor. */
    public SmelterMenu(int containerId, Inventory inventory) {
        this(containerId, inventory, new SimpleContainer(4), new SimpleContainerData(4));
    }

    public SmelterMenu(int containerId, Inventory inventory, Container container, ContainerData data) {
        super(CrystalSmelterMod.SMELTER_MENU, containerId);
        checkContainerSize(container, 4);
        checkContainerDataCount(data, 4);
        this.container = container;
        this.data = data;
        this.level = inventory.player.level();

        // Slot positions measured from Better End's smelter_gui.png
        this.addSlot(new Slot(container, SmelterBlockEntity.SLOT_A, 45, 17));
        this.addSlot(new Slot(container, SmelterBlockEntity.SLOT_B, 67, 17));
        this.addSlot(new Slot(container, SmelterBlockEntity.SLOT_FUEL, 56, 53) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return isFuel(stack);
            }
        });
        this.addSlot(new Slot(container, SmelterBlockEntity.SLOT_OUTPUT, 129, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }

            @Override
            public void onTake(Player player, ItemStack stack) {
                if (container instanceof SmelterBlockEntity smelter && player instanceof ServerPlayer serverPlayer) {
                    smelter.awardExperience(serverPlayer);
                }
                super.onTake(player, stack);
            }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, 142));
        }

        this.addDataSlots(data);
    }

    private boolean isFuel(ItemStack stack) {
        return level.fuelValues().isFuel(stack);
    }

    @Override
    public boolean stillValid(Player player) {
        return container.stillValid(player);
    }

    public boolean isLit() {
        return data.get(0) > 0;
    }

    /** Height of the flame sprite (0-14). */
    public int getLitHeight() {
        int total = data.get(1);
        if (total == 0) {
            total = 200;
        }
        return Mth.clamp(Mth.ceil(data.get(0) * 14.0F / total), 0, 14);
    }

    /** Width of the progress arrow (0-24). */
    public int getProgressWidth() {
        int progress = data.get(2);
        int total = data.get(3);
        return total != 0 && progress != 0 ? progress * 24 / total : 0;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack copy = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            copy = stack.copy();
            if (index == SmelterBlockEntity.SLOT_OUTPUT) {
                if (!this.moveItemStackTo(stack, 4, 40, true)) {
                    return ItemStack.EMPTY;
                }
                slot.onQuickCraft(stack, copy);
            } else if (index >= 4) {
                if (isFuel(stack) && this.moveItemStackTo(stack, SmelterBlockEntity.SLOT_FUEL, SmelterBlockEntity.SLOT_FUEL + 1, false)) {
                    // moved into fuel slot
                } else if (!this.moveItemStackTo(stack, 0, 2, false)) {
                    if (index < 31) {
                        if (!this.moveItemStackTo(stack, 31, 40, false)) {
                            return ItemStack.EMPTY;
                        }
                    } else if (!this.moveItemStackTo(stack, 4, 31, false)) {
                        return ItemStack.EMPTY;
                    }
                }
            } else if (!this.moveItemStackTo(stack, 4, 40, false)) {
                return ItemStack.EMPTY;
            }

            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            if (stack.getCount() == copy.getCount()) {
                return ItemStack.EMPTY;
            }
            slot.onTake(player, stack);
        }
        return copy;
    }
}
