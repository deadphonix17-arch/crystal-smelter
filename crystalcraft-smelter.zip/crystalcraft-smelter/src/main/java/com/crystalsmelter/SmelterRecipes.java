package com.crystalsmelter;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Loads smelter recipes from data/<namespace>/smelter_recipes/*.json
 *
 * {
 *   "ingredients": ["minecraft:coal", "minecraft:iron_ingot"],   // item ids or "#tag" ids, order does not matter
 *   "result": { "id": "crystalcraft_unlimited_java:steel", "count": 1 },
 *   "experience": 1.0,
 *   "time": 200
 * }
 */
public class SmelterRecipes implements SimpleSynchronousResourceReloadListener {
    private static volatile List<Recipe> RECIPES = Collections.emptyList();

    public record Recipe(String ingredientA, String ingredientB, String resultId, int resultCount, float experience, int time) {
        public ItemStack createResult() {
            Item item = BuiltInRegistries.ITEM.getValue(ResourceLocation.parse(resultId));
            if (item == Items.AIR) {
                return ItemStack.EMPTY;
            }
            return new ItemStack(item, resultCount);
        }

        public boolean matches(ItemStack a, ItemStack b) {
            return (test(ingredientA, a) && test(ingredientB, b)) || (test(ingredientA, b) && test(ingredientB, a));
        }
    }

    private static boolean test(String ingredient, ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (ingredient.startsWith("#")) {
            TagKey<Item> tag = TagKey.create(Registries.ITEM, ResourceLocation.parse(ingredient.substring(1)));
            return stack.is(tag);
        }
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString().equals(ingredient);
    }

    /** Returns the matching recipe for the two input stacks (either order), or null. */
    public static Recipe find(ItemStack a, ItemStack b) {
        if (a.isEmpty() || b.isEmpty()) {
            return null;
        }
        for (Recipe recipe : RECIPES) {
            if (recipe.matches(a, b)) {
                return recipe;
            }
        }
        return null;
    }

    @Override
    public ResourceLocation getFabricId() {
        return ResourceLocation.fromNamespaceAndPath(CrystalSmelterMod.MOD_ID, "smelter_recipes");
    }

    @Override
    public void onResourceManagerReload(ResourceManager manager) {
        List<Recipe> loaded = new ArrayList<>();
        Map<ResourceLocation, Resource> found = manager.listResources("smelter_recipes", id -> id.getPath().endsWith(".json"));
        for (Map.Entry<ResourceLocation, Resource> entry : found.entrySet()) {
            try (Reader reader = entry.getValue().openAsReader()) {
                JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                JsonArray ingredients = json.getAsJsonArray("ingredients");
                if (ingredients.size() != 2) {
                    throw new IllegalArgumentException("needs exactly 2 ingredients");
                }
                JsonObject result = json.getAsJsonObject("result");
                float xp = json.has("experience") ? json.get("experience").getAsFloat() : 0.0F;
                int time = json.has("time") ? json.get("time").getAsInt() : 200;
                int count = result.has("count") ? result.get("count").getAsInt() : 1;
                JsonElement a = ingredients.get(0);
                JsonElement b = ingredients.get(1);
                loaded.add(new Recipe(a.getAsString(), b.getAsString(), result.get("id").getAsString(), count, xp, time));
            } catch (Exception e) {
                CrystalSmelterMod.LOGGER.warn("Could not load smelter recipe {}: {}", entry.getKey(), e.toString());
            }
        }
        RECIPES = loaded;
        CrystalSmelterMod.LOGGER.info("Loaded {} smelter recipes", loaded.size());
    }
}
