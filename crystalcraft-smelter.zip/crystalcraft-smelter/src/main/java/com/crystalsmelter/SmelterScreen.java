package com.crystalsmelter;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class SmelterScreen extends AbstractContainerScreen<SmelterMenu> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CrystalSmelterMod.MOD_ID, "textures/gui/smelter_gui.png");

    public SmelterScreen(SmelterMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        this.renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, TEXTURE, leftPos, topPos, 0.0F, 0.0F, imageWidth, imageHeight, 256, 256);

        if (menu.isLit()) {
            int h = menu.getLitHeight();
            // flame sprite is at (176,0), 14x14; drawn over the steam icon, growing upward
            graphics.blit(RenderPipelines.GUI_TEXTURED, TEXTURE, leftPos + 56, topPos + 36 + 14 - h,
                    176.0F, (float) (14 - h), 14, h, 256, 256);
        }

        int w = menu.getProgressWidth();
        if (w > 0) {
            // arrow sprite is at (176,14), 24x17
            graphics.blit(RenderPipelines.GUI_TEXTURED, TEXTURE, leftPos + 91, topPos + 34,
                    176.0F, 14.0F, w, 17, 256, 256);
        }
    }
}
