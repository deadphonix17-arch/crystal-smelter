package com.crystalsmelter;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * Slots: 0 = input A, 1 = input B, 2 = fuel, 3 = output.
 * Fuel uses the game's normal fuel values, so coal blocks (and everything a furnace burns) work.
 */
public class SmelterBlockEntity extends BaseContainerBlockEntity implements WorldlyContainer {
    public static final int SLOT_A = 0;
    public static final int SLOT_B = 1;
    public static final int SLOT_FUEL = 2;
    public static final int SLOT_OUTPUT = 3;

    private static final int[] SLOTS_UP = {SLOT_A, SLOT_B};
    private static final int[] SLOTS_DOWN = {SLOT_OUTPUT};
    private static final int[] SLOTS_SIDE = {SLOT_FUEL};

    private NonNullList<ItemStack> items = NonNullList.withSize(4, ItemStack.EMPTY);
    private int litTimeRemaining;
    private int litTotalTime;
    private int cookProgress;
    private int cookTotal = 200;
    private float storedXp;

    protected final ContainerData dataAccess = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> litTimeRemaining;
                case 1 -> litTotalTime;
                case 2 -> cookProgress;
                case 3 -> cookTotal;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> litTimeRemaining = value;
                case 1 -> litTotalTime = value;
                case 2 -> cookProgress = value;
                case 3 -> cookTotal = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 4;
        }
    };

    public SmelterBlockEntity(BlockPos pos, BlockState state) {
        super(CrystalSmelterMod.SMELTER_BLOCK_ENTITY, pos, state);
    }

    // ---------------------------------------------------------------- ticking

    private boolean isLit() {
        return litTimeRemaining > 0;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, SmelterBlockEntity be) {
        boolean wasLit = be.isLit();
        boolean changed = false;

        if (be.isLit()) {
            be.litTimeRemaining--;
        }

        ItemStack a = be.items.get(SLOT_A);
        ItemStack b = be.items.get(SLOT_B);
        ItemStack fuel = be.items.get(SLOT_FUEL);

        SmelterRecipes.Recipe recipe = SmelterRecipes.find(a, b);
        boolean canWork = recipe != null && be.canOutput(recipe);

        if (recipe != null && be.cookTotal != recipe.time()) {
            be.cookTotal = recipe.time();
        }

        if (!be.isLit() && canWork && !fuel.isEmpty()) {
            int burn = level.fuelValues().burnDuration(fuel);
            if (burn > 0) {
                be.litTimeRemaining = burn;
                be.litTotalTime = burn;
                if (fuel.is(Items.LAVA_BUCKET)) {
                    be.items.set(SLOT_FUEL, new ItemStack(Items.BUCKET));
                } else {
                    fuel.shrink(1);
                }
                changed = true;
            }
        }

        if (be.isLit() && canWork) {
            be.cookProgress++;
            if (be.cookProgress >= be.cookTotal) {
                be.cookProgress = 0;
                be.craft(recipe);
            }
            changed = true;
        } else if (!canWork && be.cookProgress > 0) {
            be.cookProgress = Math.max(be.cookProgress - 2, 0);
            changed = true;
        }

        if (wasLit != be.isLit()) {
            state = state.setValue(SmelterBlock.LIT, be.isLit());
            level.setBlock(pos, state, 3);
            changed = true;
        }

        if (changed) {
            setChanged(level, pos, state);
        }
    }

    private boolean canOutput(SmelterRecipes.Recipe recipe) {
        ItemStack result = recipe.createResult();
        if (result.isEmpty()) {
            return false;
        }
        ItemStack out = items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            return true;
        }
        if (!ItemStack.isSameItemSameComponents(out, result)) {
            return false;
        }
        return out.getCount() + result.getCount() <= Math.min(getMaxStackSize(), out.getMaxStackSize());
    }

    private void craft(SmelterRecipes.Recipe recipe) {
        ItemStack result = recipe.createResult();
        ItemStack out = items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            items.set(SLOT_OUTPUT, result);
        } else {
            out.grow(result.getCount());
        }
        items.get(SLOT_A).shrink(1);
        items.get(SLOT_B).shrink(1);
        storedXp += recipe.experience();
    }

    /** Called when a player takes the output; pays out stored experience. */
    public void awardExperience(ServerPlayer player) {
        int whole = (int) Math.floor(storedXp);
        if (whole > 0) {
            storedXp -= whole;
            ExperienceOrb.award(player.level(), player.position(), whole);
        }
    }

    // ---------------------------------------------------------------- container

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.crystalcraft_smelter.end_stone_smelter");
    }

    @Override
    protected NonNullList<ItemStack> getItems() {
        return items;
    }

    @Override
    protected void setItems(NonNullList<ItemStack> newItems) {
        this.items = newItems;
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        return new SmelterMenu(containerId, inventory, this, dataAccess);
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot == SLOT_OUTPUT) {
            return false;
        }
        if (slot == SLOT_FUEL) {
            return level != null && level.fuelValues().isFuel(stack);
        }
        return true;
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        if (side == Direction.DOWN) {
            return SLOTS_DOWN;
        }
        return side == Direction.UP ? SLOTS_UP : SLOTS_SIDE;
    }

    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, Direction side) {
        return canPlaceItem(slot, stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction side) {
        return slot == SLOT_OUTPUT;
    }

    // ---------------------------------------------------------------- saving

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        this.items = NonNullList.withSize(4, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(input, this.items);
        this.litTimeRemaining = input.getIntOr("LitTime", 0);
        this.litTotalTime = input.getIntOr("LitTotal", 0);
        this.cookProgress = input.getIntOr("CookProgress", 0);
        this.cookTotal = input.getIntOr("CookTotal", 200);
        this.storedXp = input.getFloatOr("StoredXp", 0.0F);
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        ContainerHelper.saveAllItems(output, this.items);
        output.putInt("LitTime", this.litTimeRemaining);
        output.putInt("LitTotal", this.litTotalTime);
        output.putInt("CookProgress", this.cookProgress);
        output.putInt("CookTotal", this.cookTotal);
        output.putFloat("StoredXp", this.storedXp);
    }
}
