package com.crystalsmelter;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screens.MenuScreens;

public class CrystalSmelterClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MenuScreens.register(CrystalSmelterMod.SMELTER_MENU, SmelterScreen::new);
    }
}
